package com.forum.jdbc;

public class SingleConnection {

}

package com.forum.testes;

import com.forum.jdbc.Conexao;

public class TestConexao {

	public static void main(String[] args) {
		
		Conexao.getConnection();

	}

}
